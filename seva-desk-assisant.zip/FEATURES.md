# Seva Desk feature guide

A tour of everything Seva Desk does, tab by tab.

- [Getting in](#getting-in)
- [Layout and navigation](#layout-and-navigation)
- [Dashboard](#dashboard)
- [Creative studio](#creative-studio)
- [Contacts and capture](#contacts-and-capture)
- [Follow-ups](#follow-ups)
- [Chat](#chat)
- [My profile](#my-profile)
- [Admins](#admins)
- [Design and accessibility](#design-and-accessibility)

---

## Getting in

**Shared mode only: email code.** Enter your email and Seva Desk sends a one-time code. Entering the code signs you in and verifies your address. **Resend code** becomes available after 60 seconds, and **Use a different email** starts over.

**Create an account.** Fill in:
- **Required:** full name, date of birth, gender, address, email, contact number and country.
- **Optional:** Instagram, Facebook and X (Twitter).
- **I am a volunteer:** tick it to appear in the Registered volunteers list. Then choose the events you are registered for, or add a new one with an optional date.
- **Password:** at least 8 characters, typed twice.

How the email is checked depends on the mode:
- **Shared mode:** the email is filled in from your sign-in and locked, and the account is marked **Verified**.
- **Local mode:** you type it twice and the account is marked **Not verified**.

**Log in.** Use your email and password. **Keep me logged in on this device** is on by default. After 5 wrong attempts, login pauses for 30 seconds.

**Forgot password?** Confirm the phone number and date of birth you registered with, then choose a new password.

---

## Layout and navigation

- **On computers,** a sidebar menu. **On phones,** a bottom tab bar (Home, Studio, Contacts, Follow-ups, Chat, Profile). Chat shows an unread count.
- **Header** with the Seva Desk mark and your photo or initials. Click it for **My profile** or **Log out**. Escape or clicking elsewhere closes the menu.
- **Every tab** has a title and a one-line description.
- **Short confirmations** pop up at the bottom after actions, such as "Contact added", "Copied" or "Review sent".

---

## Dashboard

- **Greeting and today's date**, with shortcuts to **My contacts** and **Shared posters**.
- **Needs your attention.** Each item is clickable:
  - overdue tasks and tasks due today;
  - your events in the next 7 days;
  - unread messages;
  - people waiting 7+ days;
  - new posters shared with you;
  - poster previews waiting for your review;
  - a prompt to add your events, if you have none.

  When there's nothing to do, it turns green and says **You're all caught up**.
- **Tiles:**
  - **Contacts** opens all contacts;
  - **Talk / partner leads** opens contacts filtered to those leads;
  - **Waiting 7+ days** opens Follow-ups filtered to those people;
  - **Never contacted** opens Follow-ups filtered to new contacts.

  Filtered lists show a **Show all** link.
- **Your upcoming events.** Each event shows its date, time, venue and a countdown (Today, Tomorrow, In 5 days), plus how many contacts registered and how many haven't been contacted. It has two buttons:
  - **Follow up** opens Follow-ups for that event;
  - **Make a poster** opens the designer with the event's date, time and venue filled in.
- **New messages:** click one to open that conversation.
- **Action items for me:** mark a task done, draft a message to the linked contact, or add a new task.
- **Reach out first:** the top people to contact, ranked by score.

---

## Creative studio

### Shared posters (the default view)

- **Every published poster is shared with all volunteers.**
- **Filter** by **Country** and **Event**, including "General (no specific event)". **Clear filters** resets both.
- **Sections:**
  - **Waiting for your review:** previews sent to you;
  - **Your drafts:** previews you sent out;
  - **Shared posters:** everything published.
- **Each card** shows a preview, the title, who shared it and when, "edited by" if an admin changed it, the event and country tags, the note and a review summary.

**Buttons on a published poster:**

| Button | What it does |
|---|---|
| **Post** | Opens the poster with an editable **caption** and share buttons: **Instagram, WhatsApp, Facebook, X, LinkedIn, Telegram, Email**. Each one sends the **poster image with the caption**. Also **Save image** (full size) and **Copy caption**. |
| **View** | Large preview, details, reviews and posting. |
| **Re-use** | Loads the poster's text, colours and layout into the designer as a new poster. Uploaded backgrounds and logos aren't included. |
| **Review** | Choose **Looks good** or **Needs changes**. A comment is required for Needs changes. You can update your review later. |
| **Edit** (admins) | Opens the poster in the designer. **Save changes** updates it for everyone. |
| **Delete** (creator) | Click twice to confirm. |

**How the share buttons behave:**
- **On a phone:** the share sheet opens with the poster and caption; choose the app.
- **On a computer:** the poster image is copied and the app opens in a new tab, with the caption pre-filled for WhatsApp, Email and Telegram. Press **Ctrl+V** (or **Cmd+V**) to attach the poster. For Facebook, LinkedIn and X, use **copy the caption** and paste it too.
- **Instagram on a computer** only accepts uploads. The poster is saved and the caption copied, and the steps are shown.

### Designing a poster

Click **Design a new poster**.

- **The form** has four steps: **Event details**, **Colours and format**, **Background** and **Logo**. The **live preview** stays beside it on computers.
- **Formats:** Poster or Instagram 4:5, Square post, Story or status, and more.
- **Brand colours:** three colour pickers, defaulting to saffron, deep red and pale saffron.
- **Backgrounds:** several brand styles, your own image with a colour overlay, and a template library.
- **Logo:** upload, position, backing and size.
- **Text auto-fits,** so it never collides with the button or logo.
- **Caption:** a ready-to-post caption with the registration link, plus the same share buttons as above, and **Send to a group of contacts** by email or WhatsApp.

### Review and publish

1. **Send a preview for review.** Choose a review group: **Volunteers for one of your events**, or **specific volunteers**. Add an optional message.
2. **Reviewers** get a dashboard alert, find it under **Waiting for your review**, and answer Looks good or Needs changes.
3. **You** see the feedback under **Your drafts** and can **Continue editing**, **Send updated preview** (reviewers are asked to look again), **Publish** or **Delete**.
4. **Publish.** Tag the **event** and **country** and add an optional note. The poster appears in Shared posters for everyone.

Drafts are shown only to the creator and the chosen reviewers. Publishing straight away, without review, is also possible.

---

## Contacts and capture

### My contacts

- **You only see contacts registered for your events.** Volunteers you added from the directory always show.
- **Search** by name, organisation, email or event, and filter by **New, Contacted, In conversation or Closed**.
- **Change a contact's status** right in the list.
- **Add contact** opens a form only when clicked:
  - the event is picked from your events;
  - Speaking, Partnership, Media and Volunteer tags are added automatically from your notes;
  - the form stays open for the next person until you close it.
- **Import** takes one contact per line (`Name | Organisation | Note`) for a chosen event. **Reset sample data** is here, and asks you to click twice.

### Registered volunteers

- **Search** volunteers, and filter by **Country** and by **Event**. The event filter lists only events you are registered for.
- **Each row** shows the volunteer's country, the events you share and an "Email verified" tag, with **Chat**, **WhatsApp**, **Email** and **Add to my contacts** buttons.

### Groups

- **My groups:** private and saved on your device.
- **Shared groups:** created by admins, usable by everyone.
- **Open a group** to **Email the group** (BCC), **WhatsApp each** person or **Add all to my contacts**.
- **Groups also appear** in the designer's "Send to a group of contacts".

---

## Follow-ups

- **A ranked list** of people to contact. It can be filtered from the dashboard: waiting 7+ days, never contacted, or by event.
- **For each person,** a ready-to-edit WhatsApp or email message with a **Copy** button.
- **Mark as followed up** confirms it and moves to the next person.

---

## Chat

- **Volunteer list** with photos or initials, unread badges and the last message time.
- **Conversations** show date dividers (Today, Yesterday, dates). The latest 50 messages load first, and **Show earlier messages** loads more.
- **Search** within a conversation highlights matches.
- **On phones,** the list comes first; tap a name for a full-screen conversation and use **Back to volunteers** to return.
- **Messages are saved on the device** they were written on.

---

## My profile

- **Update profile** shows your details in **view mode**, including verified or not-verified email, country and events. **Edit profile** opens the form, with **Save changes** and **Cancel**.
- **Photo:** upload, change or remove it. Photos are cropped square and resized.
- **Reset password** requires your current password.
- **Log out** asks you to confirm.

---

## Admins

In shared mode, admins are the accounts listed in the database's `admins` table. Admins can:
- create, edit and delete **shared contact groups**;
- **edit** any published poster (changes go live for everyone, marked "edited by");
- **delete** any poster.

Volunteers who aren't admins don't see these options, and the database refuses them anyway.

---

## Design and accessibility

- **Art of Living palette:** saffron `#F3B71A`, deep red `#D31C0D` and warm sand `#DDCA98`, with a full dark mode.
- **Typeface:** Plus Jakarta Sans, falling back to system fonts.
- **Responsive** from small phones to wide screens, with safe-area support on notched phones.
- **Keyboard and screen readers:** visible focus outlines, labelled controls, announced status messages, and dialogs that close with Escape.
- **Reduced motion** is respected.
