# Deploying Seva Desk

Seva Desk is a static site: `index.html`, `config.js` and `backend.js`, with no build step. Any static host works. This guide covers putting the code on GitHub, then publishing it with **one** of GitHub Pages, Netlify or Vercel.

**Time needed:** about 10–15 minutes.

---

## Before you start

- **A GitHub account** (free): https://github.com/signup
- **The Seva Desk files.** Unzip the download so you have a `seva-desk` folder.
- **Git**, if you prefer the command line: https://git-scm.com/downloads. If you'd rather avoid the command line, the browser upload in step 1 is enough.

> **Shared mode or local mode?** You can deploy in local mode first, with `config.js` left empty, and connect the database later. When you fill in `config.js` and push the change, the live site updates automatically.

---

## Step 1: Put the code on GitHub

### Option A: in the browser (no command line)

1. Go to https://github.com/new.
2. **Repository name:** `seva-desk`. Choose **Private** or **Public**. Leave "Add a README" **unticked**, because the project already has one.
3. Click **Create repository**.
4. On the empty repository page, click **uploading an existing file**.
5. Open your `seva-desk` folder, select **everything inside it**, including the `docs` and `supabase` folders, and drag it onto the page.
   - Hidden files such as `.nojekyll` and `.gitignore` may not show in your file browser. GitHub Pages works without them, but you can add `.nojekyll` later with **Add file → Create new file**, named `.nojekyll` and left empty.
6. Write a message such as "First version of Seva Desk" and click **Commit changes**.

### Option B: with Git

```bash
cd seva-desk
git init
git add .
git commit -m "First version of Seva Desk"
git branch -M main
git remote add origin https://github.com/<your-account>/seva-desk.git
git push -u origin main
```

Check that `index.html` sits at the **top level** of the repository, not inside another folder.

---

## Step 2: Publish it (choose one)

### Option 1: GitHub Pages (simplest)

1. In the repository, open **Settings → Pages**.
2. Under **Build and deployment**:
   - **Source:** Deploy from a branch
   - **Branch:** `main`, folder `/ (root)`
3. Click **Save**.
4. Wait a minute or two, then refresh. Your address appears at the top, usually `https://<your-account>.github.io/seva-desk/`.

> GitHub Pages sites are public by default, even when the repository is private. Anyone with the link can open the sign-in screen. In shared mode, they can't see shared data without signing in, and you can limit who can sign in (see BACKEND_SETUP.md, step 4).

### Option 2: Netlify

1. Go to https://app.netlify.com and sign in with GitHub.
2. Click **Add new site → Import an existing project → GitHub**, then pick `seva-desk`.
3. Settings:
   - **Build command:** leave empty
   - **Publish directory:** `.`
4. Click **Deploy**. Your address looks like `https://<random-name>.netlify.app`. You can rename it in **Site configuration → Change site name**.

### Option 3: Vercel

1. Go to https://vercel.com/new and sign in with GitHub.
2. Import `seva-desk`.
3. **Framework preset:** Other. Leave the build and output settings empty.
4. Click **Deploy**. Your address looks like `https://seva-desk-<name>.vercel.app`.

---

## Step 3: Check the live site

1. Open your new address on a computer **and** on a phone.
2. **In local mode,** create an account, add a contact, design a poster and publish it, then try a share button.
3. **In shared mode,** you should see the **sign-in screen** asking for your email. Continue with BACKEND_SETUP.md if you haven't yet.

---

## Step 4 (optional): Use your own domain

For example, `seva.yourdomain.org`.

| Host | Where |
|---|---|
| GitHub Pages | **Settings → Pages → Custom domain**, then add a `CNAME` record at your DNS provider pointing to `<your-account>.github.io` |
| Netlify | **Domain management → Add a domain**, then follow the DNS instructions |
| Vercel | **Project → Settings → Domains → Add** |

HTTPS is set up automatically by all three hosts. Wait for the certificate to show as active before sharing the link.

> If you use shared mode, add the new address in Supabase too: **Authentication → URL Configuration → Site URL / Redirect URLs**.

---

## Updating the app

- **In the browser:** open the file on GitHub, click the pencil icon, edit it and commit.
- **With Git:** `git add . && git commit -m "Describe the change" && git push`

All three hosts republish automatically within a minute or two after each commit to `main`.

> Browsers sometimes keep the old version for a short while. If a change doesn't show, do a hard refresh: **Ctrl+Shift+R** on Windows, or **Cmd+Shift+R** on a Mac.

---

## Troubleshooting

| Problem | What to check |
|---|---|
| **404 page** | `index.html` must be at the top level of the repository and the Pages folder must be `/ (root)`. Wait a few minutes after the first deploy. |
| **Page loads but looks unstyled** | Check your connection. Fonts come from Google Fonts, but the layout should still work without them. |
| **"The shared database couldn't be reached"** | A typo in `config.js` (URL or key), the Supabase project is paused, or a network or ad blocker is blocking `cdn.jsdelivr.net` or `supabase.co`. |
| **Share buttons don't attach the poster on a computer** | Expected. Browsers can't hand files to other websites. Seva Desk copies the poster image, so press Ctrl+V or Cmd+V in the app that opens. |
| **Share sheet doesn't open on a phone** | The phone's browser must support sharing files. Recent Chrome on Android and Safari on iOS do. Otherwise the app shows a two-step fallback. |
