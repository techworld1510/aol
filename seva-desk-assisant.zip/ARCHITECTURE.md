# How Seva Desk works

## The pieces

```
Browser
├── index.html     The app (HTML + CSS + JavaScript, no framework, no build)
├── config.js      Settings: empty = local mode, filled = shared mode
└── backend.js     Storage adapter
        │
        ├── local mode     → browser storage only
        └── shared mode    → supabase-js 2.118.0 (loaded from jsDelivr, pinned)
                               ├── Supabase Auth      one-time email codes
                               ├── documents table    posters, reviews, admin groups
                               ├── server functions   merge_document, add_review, is_admin
                               └── Realtime           live updates
```

### The storage interface

The app never calls Supabase directly. It asks for three services by name:

```js
window.claude.use("db")         // shared documents, or null when not connected
window.claude.use("user")       // who is signed in, and whether they are an admin
window.claude.use("downloads")  // save a file (poster PNG)
```

This is the same interface the app uses when it runs as a claude.ai artifact, so one `index.html` works in both places. `backend.js` provides it for a self-hosted copy:

| Service | Local mode | Shared mode |
|---|---|---|
| `db` | `null`, so the app keeps posters in the browser and turns off shared groups | `collection(path)` with `orderBy`, `limit`, `onSnapshot` (initial load plus Realtime), `doc(id).set/update/delete` and `add` |
| `user` | `null` | `me()` returns the verified email; `canEdit()` returns whether the person is an admin, via the `is_admin()` server function |
| `downloads` | Browser download | Browser download |

**How writes map to the database**

| App call | Supabase |
|---|---|
| `set(data)` | `upsert` into `documents` |
| `update(patch)` | `merge_document()`, a server-side deep merge that still respects the security rules |
| `update({reviews})` on a poster | `add_review()`, which always files the review under the signed-in person's own email |
| `delete()` | `delete` with a returned row count, so a refused delete reports "not allowed" |

Errors from the security rules come back to the app as `invalid_argument`, which it shows as "You don't have permission to … here".

### Sign-in flow (shared mode)

1. `backend.js` loads supabase-js and checks for a saved session.
2. If there is no session, a full-screen sign-in asks for an email, sends a code (`signInWithOtp`) and verifies it (`verifyOtp`, type `email`).
3. The app's `use("db")` and `use("user")` calls wait until sign-in finishes.
4. The app's registration form then locks the email to the verified address and marks the profile **Verified**.
5. Visiting `?signout` signs out of Supabase.

## Data model

### Shared (Supabase `documents` table)

**Posters** (`collection = 'posters'`):

```json
{
  "status": "draft | published",
  "title": "Diwali Meditation Evening",
  "event": "World Culture Festival 2026",
  "country": "IN",
  "note": "Please share in your college groups",
  "revEvent": "World Culture Festival 2026",
  "reviewers": ["someone@example.org"],
  "rnote": "Is the date clear enough?",
  "by": "Asha", "byEmail": "asha@example.org",
  "at": 1794700000000, "ver": 2,
  "editedBy": "Admin name", "editedAt": 1794800000000,
  "thumb": "data:image/jpeg;base64,…",
  "settings": { "title": "…", "date": "…", "c1": "#F3B71A", "size": "1080x1350", "…": "…" },
  "reviews": { "lena_example_org": { "name": "Lena", "verdict": "good | changes", "comment": "…", "at": 0, "ver": 2 } }
}
```

**Admin groups** (`collection = 'data/shared/groups'`):

```json
{ "name": "WCF leads", "desc": "…", "members": [{ "name": "…", "org": "…", "email": "…", "note": "…", "event": "…" }], "by": "Asha", "at": 0 }
```

### Per browser (local storage)

| Key | Contents |
|---|---|
| `sd-accounts` | Seva Desk accounts: profile plus password hash and salt |
| `sd-profile` | Who is logged in (in `sessionStorage` if "Keep me logged in" is off) |
| `sd-users` | Registered volunteers directory |
| `sevadesk-v1` | Contacts |
| `sd-tasks` | Action items |
| `sd-chat` | Chat messages |
| `sd-events`, `sd-evdetails` | Event list and dates or venues |
| `sd-groups-<email>` | Private groups |
| `sd-posters` | Posters when no shared database is connected |
| `sd-pseen-<email>` | Which shared posters you have already seen |
| `sd-read` | Which chat messages you have read |
| `sd-tpl`, `sd-logo` | Saved poster templates and the uploaded logo |
| `sd-seed-<email>` | Marks that the sample demo data was added for this person |

## Security model

| Rule | Where it's enforced |
|---|---|
| Must be signed in to read shared data | Database (row level security) |
| Only creators and admins can change or delete a poster | Database |
| Reviewers can only add or replace their own review | Database (`add_review` derives the key from the sign-in token) |
| Only admins can create, change or delete shared groups | Database |
| Admin list can't be changed from the app | Database (no write rules on `admins`) |
| Volunteers see only contacts for their events | App (contacts are per browser) |
| Draft previews are shown only to the creator and reviewers | App. The database lets any signed-in person read drafts. |
| Seva Desk password | App: PBKDF2-SHA256, 150,000 rounds, per-account salt, 5-try lockout |

## Making changes

- **All app code is in `index.html`.** The main script is the last `<script>` block. Styles are in the `<style>` block in `<head>`.
- **Colours** are CSS variables on `:root`, such as `--pr` (saffron), `--rd` (red) and `--sd` (sand), with dark-mode values under `prefers-color-scheme: dark`.
- **Database changes:** edit `supabase/schema.sql` and run it again. Keep every statement re-runnable (`create or replace`, `if not exists`, `drop policy if exists`).
- **Updating supabase-js:** change the pinned version in `backend.js`. Choose a release that is at least two weeks old and test sign-in, publishing, reviewing and admin editing afterwards.
