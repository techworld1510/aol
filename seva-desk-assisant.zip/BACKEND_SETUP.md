# Connecting Seva Desk to its shared database (Supabase)

In shared mode, volunteers sign in with a **one-time code sent to their email**, which verifies the address. Posters, drafts, reviews and admin contact groups are then **shared live** between everyone.

Seva Desk uses [Supabase](https://supabase.com), a hosted Postgres database with sign-in built in. It has a free tier that is enough to start.

**Time needed:** about 30 minutes.

**You'll need:**
- The Seva Desk repository on GitHub (see [DEPLOYMENT.md](DEPLOYMENT.md)).
- Your live site address, for example `https://you.github.io/seva-desk/`.
- For reliable email delivery, an email sending service such as Resend, SendGrid, Brevo or Amazon SES, plus access to your domain's DNS settings. You can start without one, but read step 5.

> Supabase changes its dashboard from time to time. If a menu name differs slightly from this guide, look for the closest match or search the Supabase docs.

---

## Step 1: Create the Supabase project

1. Go to https://supabase.com/dashboard and sign up. Signing in with GitHub is easiest.
2. Click **New project**.
3. Fill in:
   - **Name:** `seva-desk`
   - **Database password:** click **Generate a password** and store it in your password manager. Seva Desk doesn't need it, but you may need it later for backups or tools.
   - **Region:** the one closest to most volunteers.
4. Click **Create new project** and wait 1–2 minutes for it to finish setting up.

---

## Step 2: Create the tables and security rules

1. In the left menu, open **SQL Editor**.
2. Click **New query**.
3. Open `supabase/schema.sql` from the repository, copy **all** of it and paste it into the editor.
4. Click **Run**. You should see "Success. No rows returned".

The script creates:

| Item | Purpose |
|---|---|
| `documents` table | Shared posters (`collection = 'posters'`) and admin groups (`collection = 'data/shared/groups'`) |
| `admins` table | Who is an admin |
| Security rules (row level security) | Only signed-in people can read; creators and admins can change or delete a poster; reviewers can only write their own review; only admins can manage shared groups |
| `merge_document`, `add_review`, `is_admin` | Small server functions the app calls |
| Realtime | New posters and reviews appear without reloading |

The script is safe to run again, for example after an update.

**Check it worked:** open **Table Editor**. You should see `documents` and `admins`, each with a "RLS enabled" label.

---

## Step 3: Turn on sign-in with an email code

By default Supabase emails a sign-in **link**. Seva Desk asks for a **code** instead, which also works when someone reads their email on a different device.

1. Open **Authentication → Sign In / Providers → Email** and make sure **Email** is **enabled**.
2. Open **Authentication → Email Templates**. Edit **two** templates so they include the code.
   - **Magic Link** template. Subject: `Your Seva Desk sign-in code`. Body:
     ```html
     <h2>Your Seva Desk sign-in code</h2>
     <p>Enter this code to sign in:</p>
     <p style="font-size:28px;font-weight:700;letter-spacing:4px">{{ .Token }}</p>
     <p>The code expires soon. If you didn't ask for it, you can ignore this email.</p>
     ```
   - **Confirm signup** template, which first-time users may receive. Use the same body, with `{{ .Token }}`.
3. Click **Save** on each.

Codes are six digits by default and can be requested once a minute. The app's **Resend code** button waits 60 seconds for this reason.

---

## Step 4: Set the site address

1. Open **Authentication → URL Configuration**.
2. **Site URL:** your live address, for example `https://you.github.io/seva-desk/`.
3. **Redirect URLs:** add the same address, plus `http://localhost:8080` if you test on your computer.
4. Click **Save**.

**Optional: limit who can sign up.** If only invited volunteers should get in, turn off **Allow new users to sign up** under **Authentication → Sign In / Providers**. Then invite people from **Authentication → Users → Invite user**.

---

## Step 5: Send emails from your own domain (strongly recommended)

Supabase's built-in email sender is for testing. It allows only a few emails per hour and its messages often land in spam. For real volunteers, connect an email service.

1. Create an account with a transactional email service such as **Resend**, **SendGrid**, **Brevo** or **Amazon SES**.
2. In that service, **add your domain** (for example `yourdomain.org`) and create the DNS records it asks for (usually SPF, DKIM and sometimes DMARC). Wait until it shows the domain as verified.
3. Create **SMTP credentials** in that service.
4. In Supabase, open **Authentication → Emails → SMTP Settings** (or **Project Settings → Authentication → SMTP**), switch on **Custom SMTP** and enter:
   - **Sender email:** for example `no-reply@yourdomain.org`
   - **Sender name:** `Seva Desk`
   - **Host, port, username and password:** from your email service
5. Save, then raise the email rate limit under **Authentication → Rate Limits** if needed.

---

## Step 6: Connect the app

1. In Supabase, click **Connect** at the top of your project, or open **Project Settings → API Keys**.
2. Copy:
   - the **Project URL**, which looks like `https://abcdefghijklmno.supabase.co`;
   - the **Publishable key**, which starts with `sb_publishable_`. If you only see "Create new API keys", click it. Older projects can use the legacy **anon** key instead.
3. In your GitHub repository, open `config.js`, click the pencil icon and fill in:

   ```js
   window.SEVA_CONFIG = {
     SUPABASE_URL: "https://abcdefghijklmno.supabase.co",
     SUPABASE_PUBLISHABLE_KEY: "sb_publishable_...",
     APP_NAME: "Seva Desk"
   };
   ```

4. Click **Commit changes**. Your host republishes in a minute or two.

> **Is it safe to commit this key?** Yes. The publishable key is designed to be public, and the security rules from step 2 protect the data. **Never** commit a **secret** key (`sb_secret_...`) or the legacy **service_role** key. If one ever leaks, rotate it in **Project Settings → API Keys**.

---

## Step 7: Make yourself an admin

Admins can manage shared contact groups and edit or delete any poster.

1. Open your live site and **sign in once** with your email code, so that your account exists.
2. In Supabase, open **SQL Editor → New query** and run, with your email:

   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'you@yourdomain.org'
   on conflict do nothing;
   ```

3. Back in Seva Desk, reload the page. The **New shared group** button (Contacts → Groups) and the **Edit** button on posters now appear.

**List admins:**
```sql
select u.email, a.added_at
from public.admins a join auth.users u on u.id = a.user_id;
```

**Remove an admin:**
```sql
delete from public.admins
where user_id = (select id from auth.users where email = 'someone@example.org');
```

---

## Step 8: Test everything

Use two browsers (or one normal and one private window) and two email addresses: **A** (admin) and **B** (volunteer).

| # | Do this | Expect |
|---|---|---|
| 1 | Open the site as A | A sign-in screen asks for your email |
| 2 | Enter A's email | A code arrives within a minute. Check spam the first time |
| 3 | Enter the code | Seva Desk's registration form opens with your email **locked** and marked **Verified** |
| 4 | Register, tick "I am a volunteer" and choose an event | The dashboard opens |
| 5 | As A: Creative studio → Design a new poster → Publish | "Published to Shared posters for all volunteers" |
| 6 | Sign in as B in the other browser and open Creative studio | A's poster appears. The dashboard shows "1 new poster shared with you" |
| 7 | As B: Review → Needs changes → comment → Send | A sees the review appear on the poster without reloading |
| 8 | As B: look for **Edit** on A's poster | Not there, because B isn't an admin |
| 9 | As A (admin): Edit the poster and save | B sees the updated poster, marked "edited by" A |
| 10 | As A: Contacts → Groups → New shared group | Saved; B can see and use it |
| 11 | As B: try to create a shared group | The button isn't shown, and the database would refuse anyway |
| 12 | Open `your-site/?signout` | You are signed out of the shared database and see the sign-in screen again |

---

## How data is organised

All shared data lives in one table:

```
documents
  collection  text    'posters' | 'data/shared/groups'
  id          text    random id
  data        jsonb   the poster or group (title, settings, preview image, reviews, …)
  created_by  uuid    the signed-in person who created it
  created_at, updated_at
```

- **Poster preview images** are stored inside `data` as compressed JPEGs of about 60–180 KB each. The full-size poster is redrawn from the design settings when someone saves or shares it.
- **Free tier:** the database storage is enough for thousands of posters. Watch **Project Settings → Usage** as you grow.

More detail is in [ARCHITECTURE.md](ARCHITECTURE.md).

---

## Backups and maintenance

- **Backups:** check what your Supabase plan includes under **Database → Backups**. For your own copy, run `select * from public.documents` in the SQL Editor and export the result as CSV, or use `pg_dump` with the database password from step 1.
- **Inactive free projects** may be paused by Supabase after a period without use. Resume them from the dashboard. Seva Desk shows "The shared database couldn't be reached" while a project is paused.
- **After updating `schema.sql`**, run it again in the SQL Editor. It updates in place.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| **No code email** | Check spam. Confirm the Magic Link and Confirm signup templates contain `{{ .Token }}` (step 3). Built-in email is limited to a few emails per hour, so set up custom SMTP (step 5). Check **Authentication → Logs**. |
| **The email has a link but no code** | The template still uses `{{ .ConfirmationURL }}`. Replace it with `{{ .Token }}` (step 3). |
| **"That code didn't work"** | Codes are single-use and expire. Use the newest email only, or click **Resend code** after 60 seconds. |
| **"Please wait a minute…"** | Supabase allows one code per minute per email. Wait and resend. |
| **"The shared database couldn't be reached"** | A typo in `config.js`, a paused project, or a network or ad blocker blocking `supabase.co` or `cdn.jsdelivr.net`. Open the browser console (F12) for details. |
| **Posters don't appear for others** | Was `schema.sql` run in full? In **Database → Publications**, `supabase_realtime` should include `documents`. Reloading should show them either way. |
| **"You don't have permission to … here"** | The security rules refused the change. Only creators and admins can change a poster, and only admins can manage shared groups. |
| **Admin buttons missing after step 7** | Make sure you inserted the right email, then reload. Sign out with `?signout` and back in if needed. |
| **Registration says "Use the email you signed in with"** | In shared mode the Seva Desk profile must use the verified sign-in email. Sign out with `?signout` to change account. |
